#!/bin/sh

corridors="corridor10 corridor20 corridor40 corridor60 corridor80 corridor100"

cinderellas="Cinderella-c1.0-GMT Cinderella-c1.5-GMT Cinderella-c1.8-GMT Cinderella-c2.0-GMT Cinderella-c3.0-GMT Cinderella-c4.0-GMT Cinderella-Example5 Cinderella-Example6-1 Cinderella-Example6-2 Cinderella-Example6-3"

# corridor_times="570 1230 3420 7360 17720 26360"

monalisa="monalisa10 monalisa10-1 monalisa10-2 monalisa10-3 monalisa10-4 monalisa20 monalisa20-1 monalisa20-2 monalisa20-3 monalisa20-4 monalisa40 monalisa40-1 monalisa40-2 monalisa40-3 monalisa40-4 monalisa-unbounded monalisa1-unbounded monalisa2-unbounded monalisa3-unbounded monalisa4-unbounded"

nims="nim123 nim145 nim356 nim444 nim555 nim556"

programs="thermostat bakery"

mkdir -p output

# Arguments:
# $1 - Name of the test
# $2 - Name of the folder
# $3 - List of files without .smt2 extension
test() {
    v=1
    echo $1
    echo "-----------------------------------------"
    for test in $3
    do
	printf "%-17s" $test

	start=$(date +"%s%3N")
	{ timeout 600 z3 $2/$test.smt2 2>&1; } > output/$test.output
	status=$?
	end=$(date +"%s%3N")
	time=$(( $end - $start ))
	if [ $status -eq 124 ]; then
	    time="TO"
	elif [ $status -ne 0 ]; then
	    time="error"
	fi
	printf "%8s" $time 
#	printf " -> time in paper: "
#	echo $nim_times | cut -d' ' -f $v
	v=$(($v + 1))
	echo ""
    done
    echo ""
}


echo "Now running evaluation of GMTs"
echo ""

test "Cinderella-Stepmother" "Cinderella" "$cinderellas"
test "Program synthesis" "ProgramSynthesis" "$programs"
test "Nim" "Nim" "$nims"
test "Corridor" "Corridor" "$corridors"
test "Monalisa" "MonaLisa" "$monalisa"
